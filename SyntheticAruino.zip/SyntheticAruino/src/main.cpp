#include <Arduino.h>
#include <Wire.h> 
#include <LiquidCrystal_I2C.h>
#include <MFRC522.h>
#include<AccelStepper.h>
#include<SPI.h>

// The X Stepper pins
#define STEPPER1_DIR_PIN 5
#define STEPPER1_STEP_PIN 2
#define enaX  8
// The Y stepper pins
#define STEPPER2_DIR_PIN 6
#define STEPPER2_STEP_PIN 3
#define enaY  7

// Define some steppers and the pins the will use
AccelStepper stepper1(1, STEPPER1_STEP_PIN, STEPPER1_DIR_PIN, enaX);
AccelStepper stepper2(1, STEPPER2_STEP_PIN, STEPPER2_DIR_PIN, enaY);


LiquidCrystal_I2C lcd(0x27,16,2); // or 0x3F


#define RST_PIN         9
#define SS_PIN          10

int UID[4];
int i;
 
int dem = 0;

int ID1[4] = {203, 067, 106, 047}; //Thẻ bật tắt đèn
int ID2[4] = {051, 215, 138, 015}; //Thẻ bật tắt đèn


MFRC522 mfrc522(SS_PIN, RST_PIN);

void manhinh();

void setup()
{
    SPI.begin();    
    mfrc522.PCD_Init();

  lcd.init();                    
  lcd.backlight();

    stepper1.setMaxSpeed(1000.0);
    stepper1.setAcceleration(200);
    stepper1.moveTo(1000);
    
    stepper2.setMaxSpeed(1000.0);
    stepper2.setAcceleration(1000.0);
    stepper2.moveTo(1000);

     pinMode(enaX,OUTPUT);
  digitalWrite(enaX,LOW);

    pinMode(enaY,OUTPUT);
  digitalWrite(enaY,LOW);
  
}

void loop() {
 
  if (mfrc522.PICC_IsNewCardPresent()) {
    if (mfrc522.PICC_ReadCardSerial()) {
      // Lấy 4 byte đầu tiên của ID thẻ

  
      lcd.setCursor(0,0);
      lcd.print("ID of the card: ");
      lcd.setCursor(0,1);
      lcd.print(" ");
      for (byte i = 0; i < mfrc522.uid.size; i++) {
        lcd.print(mfrc522.uid.uidByte[i] < 0x10 ? "0" : "");
        lcd.print(mfrc522.uid.uidByte[i]);
    }
  }
  }
  for (byte i = 0; i < mfrc522.uid.size; i++)
  {
     Serial.print(mfrc522.uid.uidByte[i] < 0x10 ? " 0" : " ");   
    UID[i] = mfrc522.uid.uidByte[i];
    Serial.print(UID[i]);
  }
   Serial.println("   ");

   if (UID[i] == ID1[i])
  {
    dem ++;
    Serial.print("Bien dem: ");
    Serial.println(dem);
    
      if ( (dem % 2) == 1) //Số lẻ đèn ON
      {
        // digitalWrite(led, HIGH);
        // Serial.println("ĐÈN ON");   
         stepper1.setCurrentPosition(0);
         stepper1.moveTo(1000);
         stepper1.runToPosition();

         stepper2.setCurrentPosition(0);
         while (stepper2.currentPosition() != 200)
         {
            stepper2.setSpeed(500);
            stepper2.runSpeed();
         }
         
         
      }
      else
      {
        // digitalWrite(led, LOW);
        // Serial.println("ĐÈN OFF");   
        stepper1.stop();    
      }
  }
  
  else
  {
    // Serial.println("SAI THẺ........");
  }

  mfrc522.PICC_HaltA();  
  mfrc522.PCD_StopCrypto1();
}



// void manhinh()
// {

// }